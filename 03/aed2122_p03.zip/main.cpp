#include "gtest/gtest.h"
#include "gmock/gmock.h"

int main(int argc, char* argv[]) {
    testing::InitGoogleTest(&argc, argv);
    std::cout << "AED 2021/2022 - Aula Pratica 3" << std::endl;
    return RUN_ALL_TESTS();
}