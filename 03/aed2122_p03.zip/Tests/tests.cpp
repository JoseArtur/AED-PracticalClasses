#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "funSearchProblem.h"

using testing::Eq;

TEST(test, facingsun){

}

TEST(test, squareR){

}

TEST(test, missingvalue){

}

TEST(test, minPages){

}
